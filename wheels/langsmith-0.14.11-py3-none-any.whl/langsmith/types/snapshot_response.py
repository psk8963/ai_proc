# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from .._models import BaseModel

__all__ = ["SnapshotResponse", "RunConfig"]


class RunConfig(BaseModel):
    """RunConfig is what sandboxes from this snapshot boot with.

    Absent on
    snapshots built before it was recorded, which run as root with their own env.
    """

    env_vars: Optional[Dict[str, str]] = None

    user: Optional[str] = None

    work_dir: Optional[str] = None


class SnapshotResponse(BaseModel):
    id: Optional[str] = None

    created_at: Optional[str] = None

    created_by: Optional[str] = None

    description: Optional[str] = None
    """
    Description says what this snapshot's image can do, so a caller can hand it to
    an agent as a capability summary.
    """

    docker_image: Optional[str] = None

    fs_capacity_bytes: Optional[int] = None

    fs_used_bytes: Optional[int] = None

    image_digest: Optional[str] = None

    labels: Optional[Dict[str, str]] = None

    memory_snapshot_size_bytes: Optional[int] = None
    """
    MemorySnapshotSizeBytes is non-nil iff the snapshot was captured with VM memory
    state. A non-nil value is the canonical signal that this snapshot can
    warm-restore from memory; nil means rootfs only.
    """

    name: Optional[str] = None

    registry_id: Optional[str] = None

    run_config: Optional[RunConfig] = None
    """RunConfig is what sandboxes from this snapshot boot with.

    Absent on snapshots built before it was recorded, which run as root with their
    own env.
    """

    source_sandbox_id: Optional[str] = None

    status: Optional[str] = None

    status_message: Optional[str] = None

    tags: Optional[List[str]] = None
    """Tags currently resolving to this snapshot, under Name.

    A snapshot with no tags is dangling — addressable only by id.
    """

    updated_at: Optional[str] = None
